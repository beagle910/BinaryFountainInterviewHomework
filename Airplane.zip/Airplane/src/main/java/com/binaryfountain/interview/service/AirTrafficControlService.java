package com.binaryfountain.interview.service;

import com.binaryfountain.interview.domain.Aircraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
//import com.binaryfountain.interview.domain.Aircraft.Types;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

@Service
public class AirTrafficControlService {


    private static final Logger logger = LoggerFactory.getLogger(AirTrafficControlService.class);
    private PriorityQueue<Aircraft> maxHeap = new PriorityQueue<>();
    @SuppressWarnings("unchecked")
	private List<Aircraft> list = new ArrayList();
    /**
     * Add and Aircraft to the queue.
     *
     * @param aircraft Aircraft to add.
     * @return Added Aircraft.
     */
    public Aircraft enqueue(Aircraft aircraft) {
        //TODO: Implement this method.
        maxHeap.add(aircraft);
        return aircraft;
    }

    /**
     * Remove and Aircraft from the queue.
     *
     * @return Aircraft removed.
     */
    public Aircraft dequeue() {
        //TODO: Implement this method.
    	Aircraft result = null;
    	if(maxHeap.isEmpty()) {
    		System.err.println("No aircrafts in queue now!!");
    	}else {
    		Aircraft current = maxHeap.poll();
    		result = current;
    	}
		return result;
    }

    /**
     * Return the aircraft in the queue.
     *
     * @return List of aircraft.
     */
    @SuppressWarnings("unchecked")
	public List<Aircraft> list() {
        //TODO: Implement this method.
    	this.list.addAll(maxHeap);
		return list;
    }
    
    public static void main(String[] args) {
    	AirTrafficControlService mys = new AirTrafficControlService();
    	Aircraft a1 = new Aircraft(Aircraft.Types.VIP, Aircraft.Sizes.LARGE);
    	Aircraft a2 = new Aircraft(Aircraft.Types.PASSENGER, Aircraft.Sizes.LARGE);
    	Aircraft a3 = new Aircraft(Aircraft.Types.PASSENGER, Aircraft.Sizes.SMALL);
    	Aircraft a4 = new Aircraft(Aircraft.Types.VIP, Aircraft.Sizes.SMALL);
    	Aircraft a5 = new Aircraft(Aircraft.Types.VIP, Aircraft.Sizes.SMALL);
    	
    
    	mys.enqueue(a1);
    	mys.enqueue(a2);
    	mys.enqueue(a3);
    	mys.enqueue(a4);
    	mys.enqueue(a5);
    	
    	List<Aircraft> l = mys.list();
    	for(int i = 0; i < l.size(); i++) {
    		System.out.println(l.get(i).getID());
    	}
    	System.out.println();
    
    	System.out.println(mys.dequeue().getID());
    	System.out.println(mys.dequeue().getID());
    	System.out.println(mys.dequeue().getID());
    	System.out.println(mys.dequeue().getID());
    	System.out.println(mys.dequeue().getID());
    	
    	
    }
    
    
}
