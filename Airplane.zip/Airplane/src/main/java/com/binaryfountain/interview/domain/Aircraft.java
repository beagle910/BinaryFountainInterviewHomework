package com.binaryfountain.interview.domain;

import java.util.Map;

public class Aircraft implements Comparable<Aircraft>{
    //TODO: Implement this class. Create new fields, classes, and/or enumerations as needed.
	public enum Types {EMERGENCY, VIP, PASSENGER, CARGO};
	public enum Sizes {SMALL, LARGE};
	public static int seed = 0;
	private int ID = 0;
	private Types Type;
	private Sizes Size;
    //map types and sizes with values in order to compare aircrafts
	private Map<Aircraft.Types, Integer> typemap = Map.of(Types.EMERGENCY, 3,Types.VIP, 2,Types.PASSENGER, 1, Types.CARGO, 0);
	private Map<Aircraft.Sizes, Integer> sizemap = Map.of(Sizes.LARGE,1,Sizes.SMALL,0);
	
/*	assign new crafts with int ID: increasing static variable seed by one
 * (in order to easy compare two aircrafts with same type and size.)
 * 
 */
	public Aircraft(Types types, Sizes size) {
		ID = ++seed;
		Type = types;
		setSize(size);	
	}
	
	public Types getType() {
		return Type;
	}

	public void setType(Types type) {
		Type = type;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public Sizes getSize() {
		return Size;
	}

	public void setSize(Sizes size) {
		Size = size;
	}
	
/*compare aircrafts first by Type then Size then ID
 * 
 */
	@Override
	public int compareTo(Aircraft o) {
		// TODO Auto-generated method stub
		
		if (typemap.get(this.Type) == typemap.get(o.Type)) {
			if(sizemap.get(o.Size) == sizemap.get(this.Size))
				return   o.ID - this.ID;
			else 
				return sizemap.get(o.Size) - sizemap.get(this.Size) ;
		}		
		return  typemap.get(o.Type) - typemap.get(this.Type);
	}
}
